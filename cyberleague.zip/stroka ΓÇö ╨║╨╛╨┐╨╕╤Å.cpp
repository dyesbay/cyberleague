#include <iostream>

#include <cmath>

using namespace std;

int main(){
 string s, t;
 int r, cnt= 0, k;
 getline(cin, s);

 getline(cin, t);
 k=t.size();

 while (1) {
 	r=s.find(t);
 	if (r<0 || r>=s.size())
 		break;
 	s.erase (r, k);
 	cnt ++;
 }
 cout << cnt;
 return 0;
}



