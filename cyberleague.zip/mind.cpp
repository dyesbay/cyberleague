#include <iostream>
#include <cmath>
using namespace std;

int MinDiviser(long long b)
{
	for (long long i = 2; i <= sqrt(b); i++)
	 {
		if (b%i == 0)
			return i;
	}
	return b;
}



int main(){
	long long n;
	cin >> n;
	long long m;
	m=MinDiviser(n);
	cout << m;
	return 0;
}